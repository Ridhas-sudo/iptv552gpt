# V3 – correctifs Android TV

- Le rapport fourni montre que le bouton « Générer Rapport de Crash » créait volontairement une RuntimeException synthétique. Le bouton est maintenant non fatal et produit un rapport clairement marqué TEST NON FATAL.
- Le mode Auto ne déduit plus l’arabe à partir de TUNIS/MBC/BEIN/MAROC/etc. L’arabe n’est sélectionné automatiquement qu’en présence d’écriture arabe ou d’un marqueur AR explicite.
- L’action d’application globale des réglages ne relance plus le moteur Sherpa et ne recharge plus silencieusement un modèle vocal. Les changements de langue vocale restent explicites.
- Le garde-fou mémoire Android TV a été ajusté pour permettre le modèle français/anglais int8 lorsque la TV dispose d’environ 400–500 Mo libres, tout en conservant un seuil de 1200 Mo pour le modèle arabe lourd.
- La logique de traduction déjà présente continue d’afficher uniquement la traduction lorsque la traduction est activée.
