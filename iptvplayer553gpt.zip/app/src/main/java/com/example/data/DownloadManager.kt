package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

class DownloadManager(private val context: Context) {

    companion object {
        private const val TAG = "DownloadManager"
        private const val CHUNK_SIZE_LIMIT = 3 * 1024 * 1024 // 3MB minimum per chunk
        private const val DEFAULT_CONCURRENCY = 6
        private const val BUFFER_SIZE = 128 * 1024 // 128KB buffer for ultra-fast disk write & network throughput
        private const val MAX_RETRIES = 3
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectionPool(okhttp3.ConnectionPool(32, 5, TimeUnit.MINUTES))
        .protocols(listOf(okhttp3.Protocol.HTTP_2, okhttp3.Protocol.HTTP_1_1))
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // Download state representation
    sealed class DownloadState {
        object Idle : DownloadState()
        data class Downloading(val progress: Float, val downloadedBytes: Long, val totalBytes: Long, val speedKbps: Double) : DownloadState()
        data class Success(val file: File) : DownloadState()
        data class Error(val message: String) : DownloadState()
    }

    private val _downloadState = MutableStateFlow<DownloadState>(DownloadState.Idle)
    val downloadState = _downloadState.asStateFlow()

    /**
     * Downloads a file from a direct HTTP stream URL with concurrent chunked support,
     * retry logic, resume capabilities, and precise timeouts.
     */
    suspend fun downloadFile(
        url: String,
        destinationFile: File,
        headers: Map<String, String> = emptyMap(),
        concurrency: Int = DEFAULT_CONCURRENCY
    ): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "Starting download from URL: $url")
        Log.d(TAG, "Destination: ${destinationFile.absolutePath}")
        
        try {
            _downloadState.value = DownloadState.Downloading(0f, 0L, -1L, 0.0)

            // Step 1: Query file metadata to check size and range capability
            val metadata = getFileMetadata(url, headers)
            val totalSize = metadata.contentLength
            val supportsRanges = metadata.supportsRanges

            Log.d(TAG, "File Size: $totalSize bytes, Supports Ranges: $supportsRanges")

            if (supportsRanges && totalSize > CHUNK_SIZE_LIMIT && concurrency > 1) {
                // Perform concurrent chunked download
                downloadChunked(url, destinationFile, totalSize, concurrency, headers)
            } else {
                // Fallback to standard streaming download
                downloadStreaming(url, destinationFile, totalSize, headers)
            }
            
            _downloadState.value = DownloadState.Success(destinationFile)
            Log.d(TAG, "Download finished successfully: ${destinationFile.absolutePath}")
            true
        } catch (e: Exception) {
            val errMsg = e.message ?: "Unknown download error"
            Log.e(TAG, "Download failed: $errMsg", e)
            _downloadState.value = DownloadState.Error(errMsg)
            false
        }
    }

    private data class FileMetadata(val contentLength: Long, val supportsRanges: Boolean)

    private fun getFileMetadata(url: String, headers: Map<String, String>): FileMetadata {
        // First try a HEAD request
        var requestBuilder = Request.Builder().url(url).head()
        headers.forEach { (k, v) -> requestBuilder.header(k, v) }
        
        try {
            client.newCall(requestBuilder.build()).execute().use { response ->
                Log.d(TAG, "[API CALL] HEAD $url - Code: ${response.code}")
                if (response.isSuccessful) {
                    val length = response.header("Content-Length")?.toLongOrNull() ?: -1L
                    val acceptRanges = response.header("Accept-Ranges")
                    val supportsRanges = acceptRanges?.equals("bytes", ignoreCase = true) == true ||
                            response.header("Content-Range") != null
                    return FileMetadata(length, supportsRanges)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "HEAD request failed, falling back to GET for metadata: ${e.message}")
        }

        // Fallback to a small GET request to inspect headers
        requestBuilder = Request.Builder().url(url).header("Range", "bytes=0-0")
        headers.forEach { (k, v) -> requestBuilder.header(k, v) }
        
        try {
            client.newCall(requestBuilder.build()).execute().use { response ->
                Log.d(TAG, "[API CALL] GET (Range) $url - Code: ${response.code}")
                if (response.isSuccessful || response.code == 206) {
                    val contentRange = response.header("Content-Range")
                    var length = -1L
                    if (contentRange != null) {
                        length = contentRange.substringAfterLast("/").trim().toLongOrNull() ?: -1L
                    }
                    if (length == -1L) {
                        length = response.header("Content-Length")?.toLongOrNull() ?: -1L
                    }
                    val supportsRanges = response.code == 206 || response.header("Accept-Ranges")?.equals("bytes", ignoreCase = true) == true
                    return FileMetadata(length, supportsRanges)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to fetch file metadata via GET: ${e.message}")
        }

        return FileMetadata(-1L, false)
    }

    private suspend fun downloadChunked(
        url: String,
        destinationFile: File,
        totalSize: Long,
        concurrency: Int,
        headers: Map<String, String>
    ) = coroutineScope {
        // Initialize file size
        RandomAccessFile(destinationFile, "rw").use { raf ->
            raf.setLength(totalSize)
        }

        val chunkSize = (totalSize + concurrency - 1) / concurrency
        val progressTracker = ProgressTracker(totalSize) { progress, downloaded, speed ->
            _downloadState.value = DownloadState.Downloading(progress, downloaded, totalSize, speed)
        }

        val deferreds = (0 until concurrency).map { i ->
            val startByte = i * chunkSize
            val endByte = if (i == concurrency - 1) totalSize - 1 else (i + 1) * chunkSize - 1
            
            async(Dispatchers.IO) {
                downloadChunkWithRetry(url, destinationFile, startByte, endByte, headers, progressTracker)
            }
        }

        deferreds.awaitAll()
    }

    private fun downloadChunkWithRetry(
        url: String,
        destinationFile: File,
        startByte: Long,
        endByte: Long,
        headers: Map<String, String>,
        progressTracker: ProgressTracker
    ) {
        var attempt = 0
        var lastException: Exception? = null
        
        while (attempt < MAX_RETRIES) {
            try {
                downloadChunkSegment(url, destinationFile, startByte, endByte, headers, progressTracker)
                return // Success
            } catch (e: Exception) {
                attempt++
                lastException = e
                Log.w(TAG, "Error downloading chunk $startByte-$endByte (Attempt $attempt/$MAX_RETRIES): ${e.message}")
                Thread.sleep(1000L * attempt) // Exponential backoff
            }
        }
        throw lastException ?: Exception("Failed to download chunk after $MAX_RETRIES retries")
    }

    private fun downloadChunkSegment(
        url: String,
        destinationFile: File,
        startByte: Long,
        endByte: Long,
        headers: Map<String, String>,
        progressTracker: ProgressTracker
    ) {
        val requestBuilder = Request.Builder()
            .url(url)
            .header("Range", "bytes=$startByte-$endByte")
            
        headers.forEach { (k, v) -> requestBuilder.header(k, v) }

        client.newCall(requestBuilder.build()).execute().use { response ->
            Log.d(TAG, "[API CALL] GET Chunk ($startByte-$endByte) - Code: ${response.code}")
            if (response.code != 206 && !response.isSuccessful) {
                throw Exception("Server did not support partial content (Code: ${response.code})")
            }

            val body = response.body ?: throw Exception("Empty response body for chunk")
            RandomAccessFile(destinationFile, "rw").use { raf ->
                raf.seek(startByte)
                
                val buffer = ByteArray(BUFFER_SIZE)
                val inputStream = body.byteStream()
                var bytesRead: Int
                
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    raf.write(buffer, 0, bytesRead)
                    progressTracker.onBytesDownloaded(bytesRead.toLong())
                }
            }
        }
    }

    private fun downloadStreaming(
        url: String,
        destinationFile: File,
        totalSize: Long,
        headers: Map<String, String>
    ) {
        val requestBuilder = Request.Builder().url(url)
        headers.forEach { (k, v) -> requestBuilder.header(k, v) }

        var attempt = 0
        var lastException: Exception? = null

        while (attempt < MAX_RETRIES) {
            try {
                client.newCall(requestBuilder.build()).execute().use { response ->
                    Log.d(TAG, "[API CALL] Streaming GET - Code: ${response.code}")
                    if (!response.isSuccessful) throw Exception("HTTP ${response.code}")

                    val body = response.body ?: throw Exception("Empty response body")
                    val progressTracker = ProgressTracker(totalSize) { progress, downloaded, speed ->
                        _downloadState.value = DownloadState.Downloading(progress, downloaded, totalSize, speed)
                    }

                    java.io.BufferedOutputStream(destinationFile.outputStream(), BUFFER_SIZE).use { output ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        val inputStream = body.byteStream()
                        var bytesRead: Int
                        
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            progressTracker.onBytesDownloaded(bytesRead.toLong())
                        }
                        output.flush()
                    }
                }
                return // Success
            } catch (e: Exception) {
                attempt++
                lastException = e
                Log.w(TAG, "Streaming download failed (Attempt $attempt/$MAX_RETRIES): ${e.message}")
                Thread.sleep(1000L * attempt)
            }
        }
        throw lastException ?: Exception("Streaming download failed after $MAX_RETRIES retries")
    }

    // Helper class to safely track multi-threaded download progress and speed
    private class ProgressTracker(
        private val totalSize: Long,
        private val onProgressUpdate: (Float, Long, Double) -> Unit
    ) {
        private var downloadedBytes: Long = 0L
        private val startTime = System.currentTimeMillis()

        @Synchronized
        fun onBytesDownloaded(bytes: Long) {
            downloadedBytes += bytes
            val durationSecs = (System.currentTimeMillis() - startTime) / 1000.0
            val speedKbps = if (durationSecs > 0) {
                (downloadedBytes / 1024.0) / durationSecs
            } else {
                0.0
            }
            val progress = if (totalSize > 0) downloadedBytes.toFloat() / totalSize else 0f
            onProgressUpdate(progress.coerceIn(0f, 1f), downloadedBytes, speedKbps)
        }
    }
}
