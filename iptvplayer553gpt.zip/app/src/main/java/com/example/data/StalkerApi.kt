package com.example.data

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

interface StalkerApi {

    @GET("server/load.php")
    fun getGenres(
        @Query("type") type: String,          // e.g., "vod", "tv_series", "itv"
        @Query("action") action: String,      // e.g., "get_genres", "get_categories", "get_series_categories"
        @Query("token") token: String,
        @Query("JsHttpRequest") jsHttpRequest: String = "1-xml"
    ): Call<String>

    @GET("server/load.php")
    fun getOrderedList(
        @Query("type") type: String,          // "vod" or "tv_series"
        @Query("action") action: String = "get_ordered_list",
        @Query("genre") genreId: String?,     // category or genre ID
        @Query("category") category: String?,  // optional fallback filter (e.g. "tv_series")
        @Query("p") page: Int,                // page number
        @Query("token") token: String,
        @Query("JsHttpRequest") jsHttpRequest: String = "1-xml"
    ): Call<String>

    @GET("server/load.php")
    fun getSeriesSeasons(
        @Query("type") type: String = "tv_series",
        @Query("action") action: String = "get_ordered_list",
        @Query("id") seriesId: String,        // series item id
        @Query("season_id") seasonId: String = "0", // 0 to get seasons
        @Query("token") token: String,
        @Query("JsHttpRequest") jsHttpRequest: String = "1-xml"
    ): Call<String>

    @GET("server/load.php")
    fun getSeriesEpisodes(
        @Query("type") type: String = "tv_series",
        @Query("action") action: String = "get_ordered_list",
        @Query("id") seriesId: String,
        @Query("season_id") seasonId: String, // specific season id
        @Query("token") token: String,
        @Query("JsHttpRequest") jsHttpRequest: String = "1-xml"
    ): Call<String>

    @GET("server/load.php")
    fun createLink(
        @Query("type") type: String,          // "vod" or "series" or "itv"
        @Query("action") action: String = "create_link",
        @Query("cmd") cmd: String,            // stream command or path
        @Query("series") series: String?,     // episode number or season_number/episode_number
        @Query("forced_storage") forcedStorage: Int = 0,
        @Query("disable_ad") disableAd: Int = 0,
        @Query("token") token: String,
        @Query("JsHttpRequest") jsHttpRequest: String = "1-xml"
    ): Call<String>
}
