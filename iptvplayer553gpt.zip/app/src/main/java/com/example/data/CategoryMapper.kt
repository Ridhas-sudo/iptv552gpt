package com.example.data

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

class CategoryMapper(
    private val authManager: StalkerAuthManager
) {
    companion object {
        private const val TAG = "CategoryMapper"
    }

    /**
     * Represents a custom IPTV category mapped to the UI tabs.
     */
    data class UiCategory(
        val id: String,
        val title: String,
        val type: ContentType // LIVE, MOVIE, SERIES
    )

    enum class ContentType {
        LIVE, MOVIE, SERIES
    }

    /**
     * Maps `get_genres` / `get_categories` responses to UI tabs, separating Movies and TV Series.
     * Prevents category flattening and handles fallback cases cleanly.
     */
    fun fetchCategories(contentType: ContentType): List<UiCategory> {
        val portalUrl = authManager.getPortalUrl()
        val token = authManager.getToken()
        if (portalUrl.isEmpty()) return emptyList()

        val client = authManager.createStalkerOkHttpClient()
        val endpointFileName = authManager.getEndpointFileName()
        val cleanPortal = if (portalUrl.endsWith("/")) portalUrl else "$portalUrl/"
        val endpoint = "${cleanPortal}${endpointFileName}"

        // Rule: Separate API actions based on content type
        val (apiType, apiActions) = when (contentType) {
            ContentType.LIVE -> "itv" to listOf("get_genres", "get_categories")
            ContentType.MOVIE -> "vod" to listOf("get_genres", "get_categories")
            ContentType.SERIES -> "tv_series" to listOf("get_genres", "get_series_categories", "get_categories")
        }

        val categoriesList = mutableListOf<UiCategory>()

        for (action in apiActions) {
            val url = "$endpoint?type=$apiType&action=$action&token=$token&JsHttpRequest=1-xml"
            Log.d(TAG, "Fetching categories for $contentType using action: $action, URL: $url")
            val request = okhttp3.Request.Builder().url(url).build()

            try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val cleaned = cleanStalkerJson(body)
                        if (cleaned.isNotEmpty()) {
                            val parsed = parseCategoriesJson(cleaned, contentType)
                            if (parsed.isNotEmpty()) {
                                categoriesList.addAll(parsed)
                                Log.d(TAG, "Successfully mapped ${parsed.size} categories with action: $action")
                                return@use // Success, exit action loop early
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching categories for $contentType action $action: ${e.message}")
            }
        }

        // Fallback for Series if `type=tv_series` returned empty or failed:
        // Some providers put series under type=vod with category=tv_series
        if (contentType == ContentType.SERIES && categoriesList.isEmpty()) {
            Log.d(TAG, "tv_series categories empty, trying type=vod category=tv_series fallback")
            val url = "$endpoint?type=vod&action=get_genres&category=tv_series&token=$token&JsHttpRequest=1-xml"
            val request = okhttp3.Request.Builder().url(url).build()
            try {
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val cleaned = cleanStalkerJson(body)
                        val parsed = parseCategoriesJson(cleaned, ContentType.SERIES)
                        if (parsed.isNotEmpty()) {
                            categoriesList.addAll(parsed)
                            Log.d(TAG, "Fallback: Found ${parsed.size} series categories under vod category=tv_series")
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Fallback series categories fetch failed: ${e.message}")
            }
        }

        return categoriesList
    }

    private fun parseCategoriesJson(jsonStr: String, contentType: ContentType): List<UiCategory> {
        val list = mutableListOf<UiCategory>()
        try {
            if (jsonStr.startsWith("[")) {
                val arr = JSONArray(jsonStr)
                parseJsonArray(arr, list, contentType)
            } else if (jsonStr.startsWith("{")) {
                val json = JSONObject(jsonStr)
                
                // Inspect js, result, or known nested keys
                val possibleArrayKeys = listOf("js", "result", "data", "results", "genres", "categories", "list")
                var parsed = false
                
                for (key in possibleArrayKeys) {
                    val arr = json.optJSONArray(key)
                    if (arr != null && arr.length() > 0) {
                        parseJsonArray(arr, list, contentType)
                        parsed = true
                        break
                    }
                }

                if (!parsed) {
                    for (key in possibleArrayKeys) {
                        val obj = json.optJSONObject(key)
                        if (obj != null) {
                            for (subKey in possibleArrayKeys) {
                                val subArr = obj.optJSONArray(subKey)
                                if (subArr != null && subArr.length() > 0) {
                                    parseJsonArray(subArr, list, contentType)
                                    parsed = true
                                    break
                                }
                            }
                            if (!parsed) {
                                parseJsonObjectDirectly(obj, list, contentType)
                                parsed = true
                            }
                            if (parsed) break
                        }
                    }
                }

                if (!parsed) {
                    parseJsonObjectDirectly(json, list, contentType)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "JSON parse error in category mapping: ${e.message}")
        }
        return list
    }

    private fun parseJsonArray(arr: JSONArray, outList: MutableList<UiCategory>, contentType: ContentType) {
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("id").ifEmpty { obj.optString("alias") }
            val title = obj.optString("title").ifEmpty { obj.optString("name") }
            if (id.isNotEmpty() && title.isNotEmpty()) {
                outList.add(UiCategory(id, title, contentType))
            }
        }
    }

    private fun parseJsonObjectDirectly(obj: JSONObject, outList: MutableList<UiCategory>, contentType: ContentType) {
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = obj.opt(key)
            if (value is JSONObject) {
                val id = value.optString("id").ifEmpty { value.optString("alias") }.ifEmpty { key }
                val title = value.optString("title").ifEmpty { value.optString("name") }
                if (id.isNotEmpty() && title.isNotEmpty()) {
                    outList.add(UiCategory(id, title, contentType))
                }
            } else if (value is String) {
                // simple key-value: e.g. "1": "Action"
                outList.add(UiCategory(key, value, contentType))
            }
        }
    }
}
