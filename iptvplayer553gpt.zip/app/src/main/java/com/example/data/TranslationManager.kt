package com.example.data

import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

data class TranslationLanguageOption(
    val code: String,
    val displayName: String
)

/**
 * Singleton de gestion de traduction instantanée des sous-titres via Google ML Kit.
 * - Extraction et nettoyage des sous-titres Live TV (CEA-608/708, WebVTT, DVB, Teletext, OCR).
 * - Vérification et téléchargement à la demande des modèles de langues.
 * - Cache en mémoire ultra-rapide pour les sous-titres en direct.
 * - Détection automatique de la langue source (Script + ML Kit + métadonnées de flux/chaîne).
 */
object TranslationManager {
    private const val TAG = "TranslationManager"

    private val modelManager = RemoteModelManager.getInstance()
    private val backgroundScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val backgroundDownloadRequested = ConcurrentHashMap.newKeySet<String>()

    // Cache en mémoire pour éviter de retraduire des phrases récurrentes
    private val translationCache = ConcurrentHashMap<String, String>()

    // Translators actifs (paire SourceLanguage -> TargetLanguage)
    private val activeTranslators = ConcurrentHashMap<Pair<String, String>, Translator>()

    private val _isDownloadingModel = MutableStateFlow(false)
    val isDownloadingModel: StateFlow<Boolean> = _isDownloadingModel.asStateFlow()

    private val _downloadProgressMessage = MutableStateFlow<String?>(null)
    val downloadProgressMessage: StateFlow<String?> = _downloadProgressMessage.asStateFlow()

    val availableLanguages = listOf(
        TranslationLanguageOption(TranslateLanguage.FRENCH, "Français"),
        TranslationLanguageOption(TranslateLanguage.ENGLISH, "Anglais"),
        TranslationLanguageOption(TranslateLanguage.SPANISH, "Español"),
        TranslationLanguageOption(TranslateLanguage.ARABIC, "العربية"),
        TranslationLanguageOption(TranslateLanguage.PORTUGUESE, "Português"),
        TranslationLanguageOption(TranslateLanguage.GERMAN, "Deutsch"),
        TranslationLanguageOption(TranslateLanguage.ITALIAN, "Italiano"),
        TranslationLanguageOption(TranslateLanguage.RUSSIAN, "Русский"),
        TranslationLanguageOption(TranslateLanguage.TURKISH, "Türkçe"),
        TranslationLanguageOption(TranslateLanguage.DUTCH, "Nederlands"),
        TranslationLanguageOption(TranslateLanguage.POLISH, "Polski"),
        TranslationLanguageOption(TranslateLanguage.BULGARIAN, "Български (Bulgare)"),
        TranslationLanguageOption(TranslateLanguage.UKRAINIAN, "Українська (Ukrainien)"),
        TranslationLanguageOption(TranslateLanguage.ROMANIAN, "Română (Roumain)"),
        TranslationLanguageOption(TranslateLanguage.GREEK, "Ελληνικά (Grec)"),
        TranslationLanguageOption(TranslateLanguage.CZECH, "Čeština (Tchèque)"),
        TranslationLanguageOption(TranslateLanguage.HUNGARIAN, "Magyar (Hongrois)"),
        TranslationLanguageOption(TranslateLanguage.SWEDISH, "Svenska (Suédois)"),
        TranslationLanguageOption(TranslateLanguage.DANISH, "Dansk (Danois)"),
        TranslationLanguageOption(TranslateLanguage.FINNISH, "Suomi (Finnois)"),
        TranslationLanguageOption(TranslateLanguage.NORWEGIAN, "Norsk (Norvégien)"),
        TranslationLanguageOption(TranslateLanguage.CROATIAN, "Hrvatski (Croate)"),
        TranslationLanguageOption(TranslateLanguage.HEBREW, "עברית (Hébreu)"),
        TranslationLanguageOption(TranslateLanguage.HINDI, "हिन्दी (Hindi)"),
        TranslationLanguageOption(TranslateLanguage.JAPANESE, "日本語"),
        TranslationLanguageOption(TranslateLanguage.KOREAN, "한국어"),
        TranslationLanguageOption(TranslateLanguage.CHINESE, "中文")
    )

    fun getLanguageDisplayName(code: String?): String {
        if (code.isNullOrBlank()) return "Auto / Inconnue"
        val clean = code.trim().lowercase()
        return when (clean) {
            "bg", "bul", "bulgarian" -> "Bulgare"
            "fr", "fra", "fre", "french" -> "Français"
            "en", "eng", "english" -> "Anglais"
            "es", "spa", "spanish" -> "Español"
            "de", "deu", "ger", "german" -> "Deutsch"
            "it", "ita", "italian" -> "Italiano"
            "pt", "por", "portuguese" -> "Português"
            "ar", "ara", "arabic" -> "العربية (Arabe)"
            "ru", "rus", "russian" -> "Русский (Russe)"
            "tr", "tur", "turkish" -> "Türkçe"
            "uk", "ukr", "ukrainian" -> "Ukrainien"
            "ro", "ron", "rum", "romanian" -> "Roumain"
            "el", "ell", "gre", "greek" -> "Grec"
            "cs", "ces", "cze", "czech" -> "Tchèque"
            "pl", "pol", "polish" -> "Polonais"
            "nl", "nld", "dut", "dutch" -> "Néerlandais"
            "hu", "hun", "hungarian" -> "Hongrois"
            "sv", "swe", "swedish" -> "Suédois"
            "da", "dan", "danish" -> "Danois"
            "fi", "fin", "finnish" -> "Finnois"
            "no", "nor", "norwegian" -> "Norvégien"
            "hr", "hrv", "croatian" -> "Croate"
            "sr", "srp", "serbian" -> "Serbe"
            "sk", "slk", "slo", "slovak" -> "Slovaque"
            "sl", "slv", "slovenian" -> "Slovène"
            "he", "heb", "iw", "hebrew" -> "Hébreu"
            "hi", "hin", "hindi" -> "Hindi"
            "ja", "jpn", "japanese" -> "Japonais"
            "ko", "kor", "korean" -> "Coréen"
            "zh", "zho", "chi", "chinese" -> "Chinois"
            "vi", "vie", "vietnamese" -> "Vietnamien"
            "id", "ind", "indonesian" -> "Indonésien"
            "th", "tha", "thai" -> "Thaï"
            "fa", "fas", "per", "persian" -> "Persan"
            else -> code.uppercase()
        }
    }

    /**
     * Nettoie le texte d'un sous-titre de ses balises HTML, WebVTT, CEA-608 et artéfacts.
     */
    fun cleanSubtitleText(raw: String): String {
        if (raw.isBlank()) return ""
        var cleaned = raw
            // Remove CEA-608 / SSA / ASS style tags
            .replace(Regex("""\{[^}]*\}"""), "")
            // Remove WebVTT / HTML tags
            .replace(Regex("""<[^>]*>"""), "")
            // Decode common HTML entities
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&nbsp;", " ")
            // Remove zero-width spaces and control characters
            .replace("\u200B", "")
            .replace("\uFEFF", "")
            .replace("\r", "")
            .trim()

        // Normalize multiple spaces / line breaks
        cleaned = cleaned.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .joinToString("\n")

        return cleaned
    }

    /**
     * Normalise un code langue (ISO-639-1 ou ISO-639-2) vers une constante de TranslateLanguage.
     */
    fun normalizeLanguageCode(code: String): String {
        val clean = code.trim().lowercase()
        val mlKitFromTag = TranslateLanguage.fromLanguageTag(clean)
        if (mlKitFromTag != null) return mlKitFromTag

        return when {
            clean in listOf("fr", "fra", "fre", "french", "français") -> TranslateLanguage.FRENCH
            clean in listOf("en", "eng", "english", "anglais") -> TranslateLanguage.ENGLISH
            clean in listOf("es", "spa", "spanish", "espagnol", "español") -> TranslateLanguage.SPANISH
            clean in listOf("de", "deu", "ger", "german", "allemand", "deutsch") -> TranslateLanguage.GERMAN
            clean in listOf("it", "ita", "italian", "italien", "italiano") -> TranslateLanguage.ITALIAN
            clean in listOf("pt", "por", "portuguese", "portugais", "português") -> TranslateLanguage.PORTUGUESE
            clean in listOf("ar", "ara", "arabic", "arabe") -> TranslateLanguage.ARABIC
            clean in listOf("ru", "rus", "russian", "russe") -> TranslateLanguage.RUSSIAN
            clean in listOf("tr", "tur", "turkish", "turc", "türkçe") -> TranslateLanguage.TURKISH
            clean in listOf("bg", "bul", "bulgarian", "bulgare") -> TranslateLanguage.BULGARIAN
            clean in listOf("uk", "ukr", "ukrainian", "ukrainien") -> TranslateLanguage.UKRAINIAN
            clean in listOf("ro", "ron", "rum", "romanian", "roumain") -> TranslateLanguage.ROMANIAN
            clean in listOf("el", "ell", "gre", "greek", "grec") -> TranslateLanguage.GREEK
            clean in listOf("cs", "ces", "cze", "czech", "tchèque") -> TranslateLanguage.CZECH
            clean in listOf("nl", "nld", "dut", "dutch", "néerlandais") -> TranslateLanguage.DUTCH
            clean in listOf("pl", "pol", "polish", "polonais") -> TranslateLanguage.POLISH
            clean in listOf("hu", "hun", "hungarian", "hongrois") -> TranslateLanguage.HUNGARIAN
            clean in listOf("sv", "swe", "swedish", "suédois") -> TranslateLanguage.SWEDISH
            clean in listOf("da", "dan", "danish", "danois") -> TranslateLanguage.DANISH
            clean in listOf("fi", "fin", "finnish", "finnois") -> TranslateLanguage.FINNISH
            clean in listOf("no", "nor", "norwegian", "norvégien") -> TranslateLanguage.NORWEGIAN
            clean in listOf("hr", "hrv", "croatian", "croate") -> TranslateLanguage.CROATIAN
            clean in listOf("he", "heb", "iw", "hebrew", "hébreu") -> TranslateLanguage.HEBREW
            clean in listOf("hi", "hin", "hindi") -> TranslateLanguage.HINDI
            clean in listOf("ja", "jpn", "japanese", "japonais") -> TranslateLanguage.JAPANESE
            clean in listOf("ko", "kor", "korean", "coréen") -> TranslateLanguage.KOREAN
            clean in listOf("zh", "zho", "chi", "chinese", "chinois") -> TranslateLanguage.CHINESE
            clean in listOf("vi", "vie", "vietnamese", "vietnamien") -> TranslateLanguage.VIETNAMESE
            clean in listOf("id", "ind", "indonesian", "indonésien") -> TranslateLanguage.INDONESIAN
            clean in listOf("th", "tha", "thai", "thaï") -> TranslateLanguage.THAI
            clean in listOf("fa", "fas", "per", "persian", "persan") -> TranslateLanguage.PERSIAN
            else -> clean.take(2).ifEmpty { TranslateLanguage.ENGLISH }
        }
    }

    /**
     * Déduit la langue depuis les scripts Unicode caractéristiques ou mots fréquents (très utile pour le Live TV).
     */
    fun detectLanguageFromScript(text: String): String? {
        val hasArabic = text.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' }
        if (hasArabic) return TranslateLanguage.ARABIC

        val hasCyrillic = text.any { it in '\u0400'..'\u04FF' }
        if (hasCyrillic) return TranslateLanguage.RUSSIAN

        val hasGreek = text.any { it in '\u0370'..'\u03FF' }
        if (hasGreek) return TranslateLanguage.GREEK

        val hasHebrew = text.any { it in '\u0590'..'\u05FF' }
        if (hasHebrew) return TranslateLanguage.HEBREW

        val hasChinese = text.any { it in '\u4E00'..'\u9FFF' }
        if (hasChinese) return TranslateLanguage.CHINESE

        val hasJapaneseKana = text.any { it in '\u3040'..'\u30FF' }
        if (hasJapaneseKana) return TranslateLanguage.JAPANESE

        val hasKorean = text.any { it in '\uAC00'..'\uD7AF' }
        if (hasKorean) return TranslateLanguage.KOREAN

        val hasHindi = text.any { it in '\u0900'..'\u097F' }
        if (hasHindi) return TranslateLanguage.HINDI

        // Détection heuristique rapide pour l'alphabet latin sur textes courts
        val lower = text.lowercase()
        val tokens = lower.split(Regex("""[\s,\.!\?:;\(\)"'\-]+""")).filter { it.isNotBlank() }.toSet()

        val frenchWords = setOf("le", "la", "les", "des", "une", "dans", "pour", "avec", "vous", "nous", "pas", "est", "qui", "que", "mais", "tout", "plus", "fait", "sont", "cette")
        val englishWords = setOf("the", "and", "that", "have", "with", "this", "from", "they", "will", "what", "about", "there", "would", "their", "here", "just", "know", "take")
        val spanishWords = setOf("los", "las", "del", "por", "para", "con", "una", "este", "esta", "como", "pero", "mas", "sus", "sobre", "todo", "tambien")
        val germanWords = setOf("und", "der", "die", "das", "nicht", "sie", "ist", "wir", "ein", "eine", "fuer", "auf", "mit", "sich")
        val italianWords = setOf("non", "che", "per", "con", "sono", "una", "questo", "della", "delle", "come", "anche")

        if (tokens.any { it in frenchWords }) return TranslateLanguage.FRENCH
        if (tokens.any { it in englishWords }) return TranslateLanguage.ENGLISH
        if (tokens.any { it in spanishWords }) return TranslateLanguage.SPANISH
        if (tokens.any { it in germanWords }) return TranslateLanguage.GERMAN
        if (tokens.any { it in italianWords }) return TranslateLanguage.ITALIAN

        return null
    }

    /**
     * Déduit la langue source à partir du groupe de chaînes ou du nom de chaîne IPTV.
     */
    fun inferLanguageFromChannel(groupName: String?, channelName: String?): String? {
        val combined = "${groupName.orEmpty()} ${channelName.orEmpty()}".uppercase()
        
        // Vérifier d'abord les caractères arabes directement présents dans le nom de la chaîne/groupe
        if (combined.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' }) {
            return TranslateLanguage.ARABIC
        }
        if (combined.any { it in '\u0400'..'\u04FF' }) {
            return TranslateLanguage.RUSSIAN
        }

        return when {
            combined.contains("ARAB") || combined.contains("BEIN") || combined.contains("OSN") || combined.contains("MBC") ||
            combined.contains("AR |") || combined.contains("AR:") || combined.contains("AR -") || combined.contains("[AR]") ||
            combined.contains("ARI ") || combined.contains("AFLAM") || combined.contains("MOSALSALAT") ||
            combined.contains("EMIRATES") || combined.contains("DUBAI") || combined.contains("ABU DHABI") ||
            combined.contains("EGYPT") || combined.contains("SAUDI") || combined.contains("QATAR") ||
            combined.contains("ALGERI") || combined.contains("MAROC") || combined.contains("MOROCCO") ||
            combined.contains("TUNISI") || combined.contains("KUWAIT") || combined.contains("LEBANON") ||
            combined.contains("LIBAN") || combined.contains("JORDAN") || combined.contains("ROTANA") ||
            combined.contains("AL JAZEERA") || combined.contains("AL ARABIYA") || combined.contains("SHAHID") -> TranslateLanguage.ARABIC

            combined.contains("FRANCE") || combined.contains("CANAL+") || combined.contains("TF1") || combined.contains("M6") ||
            combined.contains("FR |") || combined.contains("FR:") || combined.contains("FR-") || combined.contains("FR -") || combined.contains("[FR]") ||
            combined.contains(" VF") || combined.contains("(VF)") || combined.contains("[VF]") || combined.contains("VOSTFR") ||
            combined.contains("FRENCH") || combined.contains("VFF") || combined.contains("VFI") || combined.contains("BELGIUM") ||
            combined.contains("BELGIQUE") || combined.contains("SUISSE") || combined.contains("RTS") || combined.contains("RTBF") -> TranslateLanguage.FRENCH

            combined.contains("UK |") || combined.contains("UK:") || combined.contains("UK -") || combined.contains("[UK]") ||
            combined.contains("US |") || combined.contains("US:") || combined.contains("US -") || combined.contains("[US]") ||
            combined.contains("USA") || combined.contains("SKY") || combined.contains("BBC") || combined.contains("CNN") ||
            combined.contains("HBO") || combined.contains("[EN]") || combined.contains("ENGLISH") || combined.contains("ENG |") ||
            combined.contains("ENG:") || combined.contains("ENG -") || combined.contains(" VO") || combined.contains("(VO)") ||
            combined.contains("[VO]") -> TranslateLanguage.ENGLISH

            combined.contains("SPAIN") || combined.contains("ESPANA") || combined.contains("ESPAÑA") || combined.contains("ES |") ||
            combined.contains("ES:") || combined.contains("ES -") || combined.contains("MOVISTAR") || combined.contains("TELEMUNDO") ||
            combined.contains("[ES]") || combined.contains("SPANISH") || combined.contains("CASTEL") || combined.contains("LATINO") ||
            combined.contains("VOSE") || combined.contains("MEXICO") || combined.contains("COLOMBIA") || combined.contains("ARGENTINA") -> TranslateLanguage.SPANISH

            combined.contains("GERMAN") || combined.contains("DEUTSCH") || combined.contains("DE |") || combined.contains("DE:") ||
            combined.contains("DE -") || combined.contains("ZDF") || combined.contains("ARD") || combined.contains("[DE]") ||
            combined.contains("FILME") || combined.contains("AUSTRIA") -> TranslateLanguage.GERMAN

            combined.contains("ITALY") || combined.contains("ITALIA") || combined.contains("IT |") || combined.contains("IT:") ||
            combined.contains("IT -") || combined.contains("RAI") || combined.contains("MEDIASET") || combined.contains("[IT]") ||
            combined.contains("ITALIAN") -> TranslateLanguage.ITALIAN

            combined.contains("PORTUGAL") || combined.contains("BRASIL") || combined.contains("PT |") || combined.contains("PT:") ||
            combined.contains("PT -") || combined.contains("GLOBO") || combined.contains("SPORT TV") || combined.contains("[PT]") ||
            combined.contains("DUBLADO") || combined.contains("BRAZIL") -> TranslateLanguage.PORTUGUESE

            combined.contains("TURK") || combined.contains("TURKEY") || combined.contains("TR |") || combined.contains("TR:") ||
            combined.contains("TR -") || combined.contains("[TR]") || combined.contains("FILMLER") -> TranslateLanguage.TURKISH

            combined.contains("RUSS") || combined.contains("RU |") || combined.contains("RU:") || combined.contains("RU -") ||
            combined.contains("[RU]") || combined.contains("ФИЛЬМЫ") -> TranslateLanguage.RUSSIAN

            combined.contains("NETHERLANDS") || combined.contains("NEDERLAND") || combined.contains("NL |") || combined.contains("NL:") ||
            combined.contains("NL -") || combined.contains("ZIGGO") || combined.contains("[NL]") -> TranslateLanguage.DUTCH

            combined.contains("POLAND") || combined.contains("POLSKA") || combined.contains("PL |") || combined.contains("PL:") ||
            combined.contains("PL -") || combined.contains("[PL]") -> TranslateLanguage.POLISH

            combined.contains("HINDI") || combined.contains("BOLLYWOOD") || combined.contains("IN |") || combined.contains("[IN]") -> TranslateLanguage.HINDI

            else -> null
        }
    }

    /**
     * Vérifie si le modèle d'une langue cible est déjà téléchargé sur l'appareil.
     */
    suspend fun isModelDownloaded(languageCode: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val normalizedCode = normalizeLanguageCode(languageCode)
            val model = TranslateRemoteModel.Builder(normalizedCode).build()
            modelManager.isModelDownloaded(model).await()
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la vérification du modèle $languageCode: ${e.message}")
            false
        }
    }

    /**
     * Télécharge le modèle de langue si nécessaire (pour utilisation hors-ligne/locale).
     */
    suspend fun downloadModelIfNeeded(targetLanguage: String): Boolean = withContext(Dispatchers.IO) {
        val normalizedCode = normalizeLanguageCode(targetLanguage)
        try {
            if (isModelDownloaded(normalizedCode)) {
                _downloadProgressMessage.value = null
                return@withContext true
            }
            _isDownloadingModel.value = true
            _downloadProgressMessage.value = "Téléchargement du modèle (${getLanguageDisplayName(normalizedCode)})..."

            val model = TranslateRemoteModel.Builder(normalizedCode).build()
            val conditions = DownloadConditions.Builder().build()
            modelManager.download(model, conditions).await()

            // Télécharger également le modèle Anglais en arrière-plan comme source universelle s'il n'est pas déjà présent
            if (normalizedCode != TranslateLanguage.ENGLISH && !isModelDownloaded(TranslateLanguage.ENGLISH)) {
                try {
                    val enModel = TranslateRemoteModel.Builder(TranslateLanguage.ENGLISH).build()
                    modelManager.download(enModel, conditions).await()
                } catch (ignored: Exception) {}
            }

            _isDownloadingModel.value = false
            _downloadProgressMessage.value = null
            true
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors du téléchargement du modèle $normalizedCode: ${e.message}")
            _isDownloadingModel.value = false
            _downloadProgressMessage.value = "Erreur de téléchargement du modèle"
            false
        }
    }

    /**
     * Supprime un modèle de langue téléchargé pour libérer de l'espace.
     */
    suspend fun deleteModel(languageCode: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val normalizedCode = normalizeLanguageCode(languageCode)
            val model = TranslateRemoteModel.Builder(normalizedCode).build()
            modelManager.deleteDownloadedModel(model).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la suppression du modèle $languageCode: ${e.message}")
            false
        }
    }

    /**
     * Identifie automatiquement la langue source du texte en direct via ML Kit LanguageIdentification.
     */
    suspend fun identifyLanguage(text: String): String? = withContext(Dispatchers.IO) {
        val clean = cleanSubtitleText(text)
        if (clean.isBlank()) return@withContext null

        // 1. Détection immédiate par script
        val scriptLang = detectLanguageFromScript(clean)
        if (scriptLang != null) return@withContext scriptLang

        try {
            val languageIdentifier = LanguageIdentification.getClient()
            val detectedCode = languageIdentifier.identifyLanguage(clean).await()
            if (detectedCode == "und" || detectedCode.isNullOrBlank()) {
                null
            } else {
                normalizeLanguageCode(detectedCode)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Erreur d'identification de langue: ${e.message}")
            null
        }
    }

    /**
     * Traduction réseau instantanée ultra-rapide (50ms) en secours de ML Kit.
     * Ne nécessite aucun téléchargement de modèle et supporte l'auto-détection source nativement.
     */
    private suspend fun translateViaGoogleHttp(
        text: String,
        sourceLang: String?,
        targetLang: String
    ): String? = withContext(Dispatchers.IO) {
        try {
            val sl = if (sourceLang.isNullOrBlank() || sourceLang == "und" || sourceLang == "auto") "auto" else sourceLang
            val tl = targetLang
            val encoded = java.net.URLEncoder.encode(text, "UTF-8")
            val urlString = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$encoded"
            val url = java.net.URL(urlString)
            val conn = (url.openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout = 2500
                readTimeout = 3000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Mobile)")
            }
            if (conn.responseCode == 200) {
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonArray = org.json.JSONArray(response)
                val partsArray = jsonArray.optJSONArray(0)
                if (partsArray != null && partsArray.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until partsArray.length()) {
                        val part = partsArray.optJSONArray(i)
                        if (part != null) {
                            val translatedPart = part.optString(0, "")
                            sb.append(translatedPart)
                        }
                    }
                    val result = sb.toString().trim()
                    if (result.isNotBlank()) {
                        return@withContext result
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Fallback Google HTTP translation error: ${e.message}")
        }
        null
    }

    /**
     * Traduit le texte d'un sous-titre vers la langue cible spécifiée.
     * En mode traduction, renvoie UNIQUEMENT le texte traduit (jamais l'original en cas d'échec).
     */
    suspend fun translateText(
        text: String,
        sourceLanguage: String? = null,
        targetLanguage: String,
        channelGroup: String? = null,
        channelName: String? = null
    ): String = withContext(Dispatchers.IO) {
        val cleanText = cleanSubtitleText(text)
        if (cleanText.isBlank()) return@withContext ""

        val normalizedTarget = normalizeLanguageCode(targetLanguage)

        // 1. Détection automatique de la langue source (Script/Mots -> ML Kit -> Metadata piste -> Nom chaîne)
        val detected = detectLanguageFromScript(cleanText)
            ?: identifyLanguage(cleanText)
            ?: if (!sourceLanguage.isNullOrBlank() && !sourceLanguage.equals("und", ignoreCase = true) && !sourceLanguage.equals("auto", ignoreCase = true)) normalizeLanguageCode(sourceLanguage) else null
            ?: inferLanguageFromChannel(channelGroup, channelName)

        val normalizedSource = detected ?: "auto"

        // Si la langue source détectée avec certitude est déjà la langue cible demandée
        if (normalizedSource != "auto" && normalizedSource == normalizedTarget) {
            return@withContext cleanText
        }

        val cacheKey = "${normalizedSource}_${normalizedTarget}_$cleanText"
        translationCache[cacheKey]?.let { return@withContext it }

        // 2. ML Kit local UNIQUEMENT si les deux modèles sont déjà sur l'appareil.
        // Avant : translator.downloadModelIfNeeded().await() sans limite de temps -> sur une TV sans
        // téléchargement possible (ou lent) la traduction restait bloquée indéfiniment et ne passait jamais
        // au fallback HTTP : aucun texte traduit (arabe compris) n'était affiché.
        var finalTranslation: String? = null
        if (normalizedSource != "auto") {
            try {
                val modelsReady = withTimeoutOrNull(800L) {
                    isModelDownloaded(normalizedSource) && isModelDownloaded(normalizedTarget)
                } == true
                if (modelsReady) {
                    val translatorKey = Pair(normalizedSource, normalizedTarget)
                    val translator = activeTranslators.getOrPut(translatorKey) {
                        val options = TranslatorOptions.Builder()
                            .setSourceLanguage(normalizedSource)
                            .setTargetLanguage(normalizedTarget)
                            .build()
                        Translation.getClient(options)
                    }
                    val mlKitResult = withTimeoutOrNull(2500L) { translator.translate(cleanText).await() }
                    if (!mlKitResult.isNullOrBlank() && !mlKitResult.equals(cleanText, ignoreCase = true)) {
                        finalTranslation = mlKitResult
                    }
                } else {
                    // Téléchargement en arrière-plan (une seule fois par langue) pour un usage hors-ligne ultérieur
                    for (lang in listOf(normalizedSource, normalizedTarget)) {
                        if (backgroundDownloadRequested.add(lang)) {
                            backgroundScope.launch { downloadModelIfNeeded(lang) }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "ML Kit pas encore prêt ($normalizedSource -> $normalizedTarget): ${e.message}")
            }
        }

        // 3. Fallback instantané via l'API HTTP Google Translate (très rapide, auto-détection robuste)
        if (finalTranslation.isNullOrBlank()) {
            val httpResult = translateViaGoogleHttp(cleanText, if (normalizedSource == "auto") null else normalizedSource, normalizedTarget)
            if (!httpResult.isNullOrBlank() && !httpResult.equals(cleanText, ignoreCase = true)) {
                finalTranslation = httpResult
            }
        }

        // 4. Mettre en cache et renvoyer UNIQUEMENT le texte traduit (ou chaîne vide si échec, JAMAIS l'original)
        if (!finalTranslation.isNullOrBlank()) {
            translationCache[cacheKey] = finalTranslation
            finalTranslation
        } else {
            ""
        }
    }

    /**
     * Traduction directe synchrone de coroutine (translateSync).
     */
    suspend fun translateSync(text: String, source: String?, target: String): String {
        return translateText(text = text, sourceLanguage = source, targetLanguage = target)
    }

    /**
     * Vide le cache des sous-titres traduits.
     */
    fun clearCache() {
        translationCache.clear()
    }

    /**
     * Ferme tous les traducteurs actifs et vide la mémoire.
     */
    fun closeAllTranslators() {
        activeTranslators.values.forEach { try { it.close() } catch (e: Exception) { /* ignore */ } }
        activeTranslators.clear()
    }
}
