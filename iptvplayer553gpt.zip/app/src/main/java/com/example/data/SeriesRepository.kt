package com.example.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import okhttp3.Request
import okhttp3.Response
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class Series(
    val id: String,
    val name: String,
    val poster: String
)

data class Season(
    val id: String,
    val seriesId: String,
    val seasonNumber: Int,
    val name: String
)

data class Episode(
    val id: String,
    val seasonId: String,
    val seriesId: String,
    val episodeNumber: Int,
    val name: String,
    val cmd: String,
    val isPlayable: Boolean = false
)

class SeriesRepository(
    private val context: Context,
    private val apiService: ApiService,
    private val playlistId: Long
) {
    private val db = AppDatabase.getDatabase(context)
    private val dbHelper by lazy {
        val helper = SeriesDbHelper(context)
        helper.createTables(helper.writableDatabase)
        helper
    }

    /**
     * Step 1: Fetch Seasons for a Series.
     * URL: /server/load.php?type=series&action=get_ordered_list&series_id={seriesId}&token={token}&JsHttpRequest=1-xml
     * OR /server/load.php?type=series&action=get_seasons&series_id={seriesId}
     * Parse js.data -> list of seasons with id, name, season_number
     */
    fun fetchSeasons(seriesId: String): List<Season> {
        val playlist = db.playlistDao().getPlaylistById(playlistId) ?: return emptyList()
        val mac = playlist.macAddress ?: ""
        val formattedMac = formatMacAddress(mac)
        val handshakeResult = apiService.performHandshake(playlist.url, formattedMac)
        val token = handshakeResult.token
        val endpoint = handshakeResult.endpointPath
        val cleanUrl = if (handshakeResult.resolvedUrl.endsWith("/")) handshakeResult.resolvedUrl else "${handshakeResult.resolvedUrl}/"

        val deviceFields = generateStalkerDeviceFields(formattedMac)
        val devId = deviceFields["device_id"] ?: ""
        var devId2 = deviceFields["device_id2"] ?: ""
        if (cleanUrl.contains("deirnet.ps", ignoreCase = true) || playlist.url.contains("deirnet.ps", ignoreCase = true)) {
            devId2 = ""
        }
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        val url = "${cleanUrl}${endpoint}?type=vod&action=get_ordered_list&movie_id=$seriesId&season_id=0&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=1&token=$token&JsHttpRequest=1-xml"
        Log.d("SeriesRepository", "fetchSeasons URL: $url")

        val request = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp main release 0.2.18")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
            .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; ad=1")
            .header("Referer", "${cleanUrl}an_index.html")
            .header("Authorization", "Bearer $token")
            .build()

        val client = getUnsafeOkHttpClient()
        val seasons = mutableListOf<Season>()

        try {
            client.newCall(request).execute().use { response: Response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val cleaned = cleanStalkerJson(body)
                    val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                    
                    val jsVal = jsonObj?.optJSONObject("js") ?: jsonObj?.optJSONObject("result") ?: jsonObj
                    val dataArray = jsVal?.optJSONArray("data") ?: jsVal?.optJSONArray("results") ?: jsVal?.optJSONArray("seasons")

                    if (dataArray != null) {
                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.optJSONObject(i) ?: continue
                            val id = obj.optString("id").ifEmpty { obj.optString("season_id") }.ifEmpty { i.toString() }
                            val name = obj.optString("name").ifEmpty { obj.optString("title") }.ifEmpty { "Season ${i + 1}" }
                            val seasonNumber = obj.optInt("season_number", obj.optInt("season_num", obj.optInt("series_number", i + 1)))

                            // Filter fake categories "All" / "*"
                            val nameLower = name.lowercase().trim()
                            if (nameLower == "all" || nameLower == "*" || nameLower == "tous" || nameLower == "all seasons" || id == "all" || id == "*") {
                                continue
                            }

                            seasons.add(Season(id = id, seriesId = seriesId, seasonNumber = seasonNumber, name = name))
                        }
                    } else {
                        val seasonsObj = jsVal?.optJSONObject("seasons")
                        if (seasonsObj != null) {
                            val keys = seasonsObj.keys()
                            while (keys.hasNext()) {
                                val key = keys.next()
                                val sObj = seasonsObj.optJSONObject(key)
                                if (sObj != null) {
                                    val id = sObj.optString("id").ifEmpty { key }
                                    val name = sObj.optString("name").ifEmpty { "Season $key" }
                                    val seasonNumber = sObj.optInt("season_number", sObj.optInt("season_num", key.toIntOrNull() ?: 1))

                                    val nameLower = name.lowercase().trim()
                                    if (nameLower == "all" || nameLower == "*" || nameLower == "tous" || nameLower == "all seasons" || id == "all" || id == "*") {
                                        continue
                                    }

                                    seasons.add(Season(id = id, seriesId = seriesId, seasonNumber = seasonNumber, name = name))
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SeriesRepository", "Error fetching seasons: ${e.message}", e)
        }

        // Try get_seasons fallback if empty
        if (seasons.isEmpty()) {
            val fallbackUrl = "${cleanUrl}${endpoint}?type=series&action=get_seasons&series_id=$seriesId"
            val fbRequest = Request.Builder().url(fallbackUrl)
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp main release 0.2.18")
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; ad=1")
                .header("Referer", "${cleanUrl}an_index.html")
                .header("Authorization", "Bearer $token")
                .build()
            try {
                client.newCall(fbRequest).execute().use { response: Response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val cleaned = cleanStalkerJson(body)
                        val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                        val jsVal = jsonObj?.optJSONObject("js") ?: jsonObj?.optJSONObject("result") ?: jsonObj
                        val dataArray = jsVal?.optJSONArray("data") ?: jsVal?.optJSONArray("results")
                        if (dataArray != null) {
                            for (i in 0 until dataArray.length()) {
                                val obj = dataArray.optJSONObject(i) ?: continue
                                val id = obj.optString("id").ifEmpty { obj.optString("season_id") }.ifEmpty { i.toString() }
                                val name = obj.optString("name").ifEmpty { obj.optString("title") }.ifEmpty { "Season ${i + 1}" }
                                val seasonNumber = obj.optInt("season_number", obj.optInt("season_num", obj.optInt("series_number", i + 1)))

                                val nameLower = name.lowercase().trim()
                                if (nameLower == "all" || nameLower == "*" || nameLower == "tous" || nameLower == "all seasons" || id == "all" || id == "*") {
                                    continue
                                }

                                seasons.add(Season(id = id, seriesId = seriesId, seasonNumber = seasonNumber, name = name))
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("SeriesRepository", "Error with get_seasons fallback: ${e.message}")
            }
        }

        if (seasons.isEmpty()) {
            seasons.add(Season(id = "1", seriesId = seriesId, seasonNumber = 1, name = "Season 1"))
        }

        val sqliteDb = dbHelper.writableDatabase
        sqliteDb.beginTransaction()
        try {
            for (season in seasons) {
                val values = ContentValues().apply {
                    put("id", season.id)
                    put("seriesId", season.seriesId)
                    put("seasonNumber", season.seasonNumber)
                    put("name", season.name)
                }
                sqliteDb.insertWithOnConflict("seasons", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            sqliteDb.setTransactionSuccessful()
        } finally {
            sqliteDb.endTransaction()
        }

        return seasons
    }

    /**
     * Step 2: Fetch Episodes for a Series Season.
     * URL: /server/load.php?type=series&action=get_ordered_list&season_id={seasonId}&p={page}&token={token}&JsHttpRequest=1-xml
     * Parse js.data -> episodes for THAT season only. Loop p=1 until empty with delay 400ms.
     */
    fun fetchEpisodesForSeason(seasonId: String): List<Episode> {
        val playlist = db.playlistDao().getPlaylistById(playlistId) ?: return emptyList()
        val mac = playlist.macAddress ?: ""
        val formattedMac = formatMacAddress(mac)
        val handshakeResult = apiService.performHandshake(playlist.url, formattedMac)
        val token = handshakeResult.token
        val endpoint = handshakeResult.endpointPath
        val cleanUrl = if (handshakeResult.resolvedUrl.endsWith("/")) handshakeResult.resolvedUrl else "${handshakeResult.resolvedUrl}/"

        val deviceFields = generateStalkerDeviceFields(formattedMac)
        val devId = deviceFields["device_id"] ?: ""
        var devId2 = deviceFields["device_id2"] ?: ""
        if (cleanUrl.contains("deirnet.ps", ignoreCase = true) || playlist.url.contains("deirnet.ps", ignoreCase = true)) {
            devId2 = ""
        }
        val sig = deviceFields["signature"] ?: ""
        val serial = deviceFields["serial_number"] ?: ""

        var seriesId = ""
        val sqliteDb = dbHelper.readableDatabase
        val cursor = sqliteDb.rawQuery("SELECT seriesId FROM seasons WHERE id = ?", arrayOf(seasonId))
        cursor.use {
            if (it.moveToFirst()) {
                seriesId = it.getString(0)
            }
        }
        if (seriesId.isEmpty()) {
            seriesId = "unknown"
        }

        val episodes = mutableListOf<Episode>()
        val client = getUnsafeOkHttpClient()
        var page = 1
        var hasMore = true

        while (hasMore) {
            val url = "${cleanUrl}${endpoint}?type=vod&action=get_ordered_list&movie_id=$seriesId&season_id=$seasonId&episode_id=0&category=&fav=0&sortby=added&hd=0&not_ended=0&p=$page&token=$token&JsHttpRequest=1-xml"
            Log.d("SeriesRepository", "fetchEpisodesForSeason URL: $url")

            val request = Request.Builder().url(url)
                .header("User-Agent", "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp main release 0.2.18")
                .header("X-User-Agent", "Model: MAG250; Link: WiFi")
                .header("X-User-Card", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; device_id=$devId; device_id2=$devId2; signature=$sig; serial_number=$serial")
                .header("Cookie", "mac=$formattedMac; stb_lang=en; timezone=Europe/Paris; ad=1")
                .header("Referer", "${cleanUrl}an_index.html")
                .header("Authorization", "Bearer $token")
                .build()

            try {
                client.newCall(request).execute().use { response: Response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: ""
                        val cleaned = cleanStalkerJson(body)
                        val jsonObj = try { JSONObject(cleaned) } catch (e: Exception) { null }
                        
                        val jsVal = jsonObj?.optJSONObject("js") ?: jsonObj?.optJSONObject("result") ?: jsonObj
                        val dataArray = jsVal?.optJSONArray("data") ?: jsVal?.optJSONArray("results")

                        if (dataArray != null && dataArray.length() > 0) {
                            for (i in 0 until dataArray.length()) {
                                val obj = dataArray.optJSONObject(i) ?: continue
                                val id = obj.optString("id").ifEmpty { obj.optString("episode_id") }.ifEmpty { "${seasonId}_${episodes.size + 1}" }
                                val name = obj.optString("name").ifEmpty { obj.optString("title") }.ifEmpty { "Episode ${episodes.size + 1}" }
                                val cmd = obj.optString("cmd").ifEmpty { obj.optString("path") }.ifEmpty { obj.optString("url") }
                                val episodeNumber = obj.optInt("episode_number", obj.optInt("episode_num", obj.optInt("series_number", episodes.size + 1)))

                                if (cmd.isNotEmpty()) {
                                    episodes.add(
                                        Episode(
                                            id = id,
                                            seasonId = seasonId,
                                            seriesId = seriesId,
                                            episodeNumber = episodeNumber,
                                            name = name,
                                            cmd = cmd,
                                            isPlayable = false
                                        )
                                    )
                                }
                            }
                            page++
                            Thread.sleep(400) // Delay 400ms between page requests to prevent ban
                        } else {
                            hasMore = false
                        }
                    } else {
                        hasMore = false
                    }
                }
            } catch (e: Exception) {
                Log.e("SeriesRepository", "Error fetching episodes on page $page: ${e.message}", e)
                hasMore = false
            }
        }

        if (episodes.isNotEmpty()) {
            val writeDb = dbHelper.writableDatabase
            writeDb.beginTransaction()
            try {
                writeDb.delete("episodes", "seasonId = ?", arrayOf(seasonId))
                for (episode in episodes) {
                    val values = ContentValues().apply {
                        put("id", episode.id)
                        put("seasonId", episode.seasonId)
                        put("seriesId", episode.seriesId)
                        put("episodeNumber", episode.episodeNumber)
                        put("name", episode.name)
                        put("cmd", episode.cmd)
                        put("isPlayable", if (episode.isPlayable) 1 else 0)
                    }
                    writeDb.insertWithOnConflict("episodes", null, values, SQLiteDatabase.CONFLICT_REPLACE)
                }
                writeDb.setTransactionSuccessful()
            } finally {
                writeDb.endTransaction()
            }
        }

        return episodes
    }

    /**
     * Step 3: Fetch all seasons and episodes for a Series.
     */
    fun fetchAllForSeries(seriesId: String): Map<Season, List<Episode>> {
        val seasons = fetchSeasons(seriesId)
        val map = mutableMapOf<Season, List<Episode>>()
        for (season in seasons) {
            Thread.sleep(400) // Delay 400ms to avoid portal bans
            val episodes = fetchEpisodesForSeason(season.id)
            map[season] = episodes
        }
        return map
    }

    /**
     * Step 4: Resolve dynamic play link.
     * URL: /server/load.php?type=vod&action=create_link&cmd={episode.cmd}&series={seriesId}&token={token}&JsHttpRequest=1-xml
     */
    fun playEpisode(episode: Episode): String {
        val playlist = db.playlistDao().getPlaylistById(playlistId) ?: return ""
        val mac = playlist.macAddress ?: ""
        val stalkerCmd = "stalker://series/${episode.seriesId}?cmd=${URLEncoder.encode(episode.cmd, "UTF-8")}&season_id=${episode.seasonId}&episode_id=${episode.id}"
        val resolved = apiService.resolveStalkerStream(playlist.url, mac, stalkerCmd, "Series")
        if (!resolved.isNullOrEmpty()) {
            val sqliteDb = dbHelper.writableDatabase
            val values = ContentValues().apply {
                put("isPlayable", 1)
            }
            sqliteDb.update("episodes", values, "id = ?", arrayOf(episode.id))
            Log.d("VodPlaybackDebug", "[SeriesRepository] Episode stream résolu avec succès: $resolved")
            return resolved
        }
        return ""
    }
}

private class SeriesDbHelper(context: Context) : SQLiteOpenHelper(context, "iptv_series.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        createTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        createTables(db)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
    }

    fun createTables(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS series (
                id TEXT PRIMARY KEY,
                name TEXT,
                poster TEXT
            )
        """)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS seasons (
                id TEXT PRIMARY KEY,
                seriesId TEXT,
                seasonNumber INTEGER,
                name TEXT
            )
        """)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS episodes (
                id TEXT PRIMARY KEY,
                seasonId TEXT,
                seriesId TEXT,
                episodeNumber INTEGER,
                name TEXT,
                cmd TEXT,
                isPlayable INTEGER DEFAULT 0
            )
        """)
    }
}
