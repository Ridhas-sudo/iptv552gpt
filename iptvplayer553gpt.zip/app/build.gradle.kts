import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

fun sha256(file: java.io.File): String {
    val digest = MessageDigest.getInstance("SHA-256")
    file.inputStream().use { input ->
        val buffer = ByteArray(1024 * 1024)
        while (true) {
            val n = input.read(buffer)
            if (n <= 0) break
            digest.update(buffer, 0, n)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

fun ensureSherpaAar() {
    val file = file("libs/sherpa-onnx-1.10.42.aar")
    val expectedSha256 = "4f87624cc0290e4564e221844092119df1a9d721de791b4e8f145e8a73e4c9bc"
    if (file.isFile && file.length() > 30_000_000L && sha256(file) == expectedSha256) {
        println("Sherpa-ONNX AAR already present and verified: ${file.length()} bytes")
        return
    }

    file.parentFile.mkdirs()
    if (file.exists()) file.delete()

    val url = URL("https://huggingface.co/csukuangfj/sherpa-onnx-libs/resolve/18cf1324a8a7e3e17cfac1dee4487cefd9ca5e32/android/aar/sherpa-onnx-1.10.42.aar")
    println("Downloading official Sherpa-ONNX 1.10.42 AAR...")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 30_000
        readTimeout = 180_000
        instanceFollowRedirects = true
        requestMethod = "GET"
    }
    try {
        check(connection.responseCode in 200..299) {
            "Sherpa-ONNX download failed: HTTP ${connection.responseCode}"
        }
        connection.inputStream.use { input ->
            file.outputStream().use { output ->
                input.copyTo(output)
            }
        }
    } finally {
        connection.disconnect()
    }

    check(file.isFile && file.length() > 30_000_000L) {
        "Downloaded Sherpa-ONNX AAR is missing or too small: ${file.length()} bytes"
    }
    check(sha256(file) == expectedSha256) {
        "Sherpa-ONNX AAR SHA-256 mismatch"
    }
    println("Sherpa-ONNX AAR downloaded and verified: ${file.length()} bytes")
}

ensureSherpaAar()


android {
    namespace = "com.example"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.aistudio.proiptv.kxypt"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isShrinkResources = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.13"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Jetpack Compose
    implementation("androidx.compose.ui:ui:1.6.1")
    implementation("androidx.compose.ui:ui-graphics:1.6.1")
    implementation("androidx.compose.ui:ui-tooling-preview:1.6.1")
    implementation("androidx.compose.material3:material3:1.2.0")
    implementation("androidx.compose.material:material-icons-extended:1.6.1")
    implementation("androidx.compose.animation:animation:1.6.1")

    // Media3 / ExoPlayer
    implementation("androidx.media3:media3-exoplayer:1.2.1")
    implementation("androidx.media3:media3-ui:1.2.1")
    implementation("androidx.media3:media3-common:1.2.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.2.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.2.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.2.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.2.1")

    // Network / JSON
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-urlconnection:4.12.0")
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    // Images
    implementation("io.coil-kt:coil-compose:2.6.0")

    // ML Kit
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // Sherpa-ONNX AAR is downloaded by the GitHub Actions workflow into app/libs.
    implementation(files("libs/sherpa-onnx-1.10.42.aar"))

    // Tests
    testImplementation("junit:junit:4.13.2")
    testImplementation("androidx.test:core:1.5.0")
    testImplementation("org.robolectric:robolectric:4.11.1")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
