<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally or install the pre-compiled APK directly.

View your app in AI Studio: https://ai.studio/apps/fc59fe7b-5ede-4412-856b-9c169cf15820

## 📦 Direct APK Installation (Android TV, Fire TV, Smartphone, Tablet)

The complete, ready-to-install application package is included in the project root:
- **`Pro_IPTV.apk`** (also available as `pro_iptv.apk` and `pro_iptv_installer.apk`)

You can install it directly onto your Android TV or Android device via USB drive, ADB, or a file manager app like Downloader / Send Files to TV:
```bash
adb install -r Pro_IPTV.apk
```

## 🛠️ Build & Run from Source in Android Studio

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.
