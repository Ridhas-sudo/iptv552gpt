import os
import subprocess
import sys
import wave
import numpy as np

try:
    import sherpa_onnx
except ImportError:
    print("ERREUR: sherpa-onnx n'est pas installé. Exécutez: pip install sherpa-onnx")
    sys.exit(1)


def format_srt_timestamp(seconds: float) -> str:
    """Convertit un timestamp en secondes au format standard SRT : HH:MM:SS,mmm"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int(round((seconds - int(seconds)) * 1000))
    if millis >= 1000:
        secs += 1
        millis = 0
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def extract_audio_to_wav(video_path: str, wav_path: str):
    """Extrait l'audio d'une vidéo MP4/MKV en WAV 16kHz mono 16-bit à l'aide de FFmpeg."""
    cmd = [
        "ffmpeg",
        "-y",
        "-hide_banner",
        "-loglevel", "error",
        "-i", video_path,
        "-vn", "-sn", "-dn",
        "-acodec", "pcm_s16le",
        "-ac", "1",
        "-ar", "16000",
        wav_path
    ]
    subprocess.check_call(cmd)


def generate_srt_from_vod(file_path: str, output_srt: str = None, model_dir: str = None) -> str:
    """
    Transcrit un fichier MP4/MKV VOD complet avec sherpa_onnx.OfflineRecognizer
    et génère un fichier .srt avec timestamps normalisés.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Fichier vidéo introuvable : {file_path}")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    if model_dir is None:
        model_dir = os.path.join(base_dir, "models", "sherpa-onnx-whisper-small")

    # Vérification des fichiers du modèle Whisper-small
    encoder_path = os.path.join(model_dir, "small-encoder.int8.onnx")
    decoder_path = os.path.join(model_dir, "small-decoder.int8.onnx")
    tokens_path = os.path.join(model_dir, "small-tokens.txt")

    # Fallback vers version float32 si int8 non trouvée
    if not os.path.exists(encoder_path):
        encoder_path = os.path.join(model_dir, "small-encoder.onnx")
        decoder_path = os.path.join(model_dir, "small-decoder.onnx")

    if not os.path.exists(encoder_path) or not os.path.exists(tokens_path):
        raise FileNotFoundError(
            f"Modèle Whisper-small introuvable dans {model_dir}. "
            "Veuillez exécuter: bash server/download_models.sh"
        )

    # 1. Extraction de l'audio via FFmpeg vers un fichier temporaire .wav
    temp_wav = file_path + ".temp_16k.wav"
    try:
        print(f"Extraction audio en cours depuis : {file_path}...")
        extract_audio_to_wav(file_path, temp_wav)

        # 2. Lecture du fichier WAV
        with wave.open(temp_wav, "rb") as wf:
            num_channels = wf.getnchannels()
            sample_rate = wf.getframerate()
            num_frames = wf.getnframes()
            audio_bytes = wf.readframes(num_frames)

        samples = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0

        # 3. Initialisation du OfflineRecognizer Whisper
        print(f"Initialisation de sherpa_onnx.OfflineRecognizer (Whisper-small)...")
        recognizer = sherpa_onnx.OfflineRecognizer.from_whisper(
            encoder=encoder_path,
            decoder=decoder_path,
            tokens=tokens_path,
            language="fr",
            task="transcribe",
            num_threads=4,
            provider="cpu"
        )

        # 4. Transcription du flux audio
        print(f"Transcription en cours ({len(samples)/sample_rate:.1f} secondes d'audio)...")
        stream = recognizer.create_stream()
        stream.accept_waveform(sample_rate, samples)
        recognizer.decode_stream(stream)

        result = recognizer.get_result(stream)

        # 5. Découpage en sous-titres et génération du fichier SRT
        if output_srt is None:
            output_srt = os.path.splitext(file_path)[0] + ".srt"

        subtitles_entries = []
        
        # Whisper fournit soit des timestamps par segment, soit un texte global
        timestamps = getattr(result, "timestamps", [])
        tokens = getattr(result, "tokens", [])
        text = getattr(result, "text", "").strip()

        # Si sherpa-onnx fournit des timestamps par token/mot
        if timestamps and len(timestamps) > 0 and len(tokens) == len(timestamps):
            chunk_tokens = []
            chunk_start = timestamps[0]
            last_end = timestamps[0]
            max_words_per_line = 10
            max_duration = 4.0

            for tok, ts in zip(tokens, timestamps):
                chunk_tokens.append(tok)
                last_end = ts
                
                # Découper sur ponctuation ou longueur
                is_sentence_end = tok.endswith(('.', '?', '!'))
                is_too_long = (ts - chunk_start >= max_duration) or (len(chunk_tokens) >= max_words_per_line)
                
                if (is_sentence_end or is_too_long) and chunk_tokens:
                    line_text = "".join(chunk_tokens).replace(" ", " ").strip()
                    if line_text:
                        subtitles_entries.append((chunk_start, last_end + 0.5, line_text))
                    chunk_tokens = []
                    chunk_start = last_end + 0.5

            if chunk_tokens:
                line_text = "".join(chunk_tokens).replace(" ", " ").strip()
                if line_text:
                    subtitles_entries.append((chunk_start, last_end + 0.5, line_text))
        else:
            # Fallback simple par division temporelle
            total_duration = len(samples) / float(sample_rate)
            words = text.split()
            words_per_chunk = 8
            if words:
                chunk_duration = total_duration / max(1, (len(words) / words_per_chunk))
                for i in range(0, len(words), words_per_chunk):
                    chunk_text = " ".join(words[i:i + words_per_chunk])
                    t_start = (i / len(words)) * total_duration
                    t_end = min(total_duration, t_start + chunk_duration)
                    subtitles_entries.append((t_start, t_end, chunk_text))

        # Écriture du fichier .srt standard
        with open(output_srt, "w", encoding="utf-8") as f:
            for idx, (s_start, s_end, s_text) in enumerate(subtitles_entries, start=1):
                f.write(f"{idx}\n")
                f.write(f"{format_srt_timestamp(s_start)} --> {format_srt_timestamp(s_end)}\n")
                f.write(f"{s_text}\n\n")

        print(f"Sous-titres générés avec succès : {output_srt} ({len(subtitles_entries)} répliques)")
        return output_srt

    finally:
        if os.path.exists(temp_wav):
            os.remove(temp_wav)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python vod_transcriber.py <chemin_video_mp4_mkv> [chemin_sortie.srt]")
        sys.exit(1)

    video_input = sys.argv[1]
    srt_output = sys.argv[2] if len(sys.argv) > 2 else None
    generate_srt_from_vod(video_input, srt_output)
