#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Serveur Live de Sous-titrage Vocal Automatique avec Sherpa-ONNX et FFmpeg
-------------------------------------------------------------------------
- Extrait en temps réel l'audio PCM 16kHz mono depuis une URL de flux HLS (.m3u8).
- Décode l'audio avec sherpa-onnx (OnlineRecognizer Streaming Zipformer) et VAD.
- Diffuse les sous-titres via WebSocket (/ws/live?url=...) au format JSON :
  {"text": "...", "pts": 12.34, "is_final": true}
"""

import asyncio
import json
import logging
import os
import subprocess
import sys
import time
from typing import Dict, Set
import numpy as np

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
import uvicorn

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("LiveSubtitleServer")

app = FastAPI(title="Sherpa-ONNX Live Subtitle Server")

try:
    import sherpa_onnx
except ImportError:
    logger.error("sherpa-onnx n'est pas installé. Exécutez: pip install sherpa-onnx")
    sys.exit(1)

# Dossier des modèles
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")

# 1. Modèle Streaming Zipformer Français / Multilingue (chargé une seule fois)
STREAMING_DIR = os.path.join(MODELS_DIR, "sherpa-onnx-streaming-zipformer-fr-2023-04-14")
TOKENS_PATH = os.path.join(STREAMING_DIR, "tokens.txt")
ENCODER_PATH = os.path.join(STREAMING_DIR, "encoder-epoch-29-avg-9-with-averaged-model.int8.onnx")
DECODER_PATH = os.path.join(STREAMING_DIR, "decoder-epoch-29-avg-9-with-averaged-model.onnx")
JOINER_PATH = os.path.join(STREAMING_DIR, "joiner-epoch-29-avg-9-with-averaged-model.int8.onnx")

# Fallback si modèle bilingual ou autre présent
if not os.path.exists(ENCODER_PATH):
    # Chercher un modèle int8 alternatif dans le dossier models
    for candidate in [
        "sherpa-onnx-streaming-zipformer-bilingual-zh-en-2023-02-20",
        "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10"
    ]:
        cand_dir = os.path.join(MODELS_DIR, candidate)
        if os.path.exists(cand_dir):
            STREAMING_DIR = cand_dir
            TOKENS_PATH = os.path.join(STREAMING_DIR, "tokens.txt")
            for f in os.listdir(cand_dir):
                if "encoder" in f and (f.endswith(".int8.onnx") or f.endswith(".onnx")):
                    ENCODER_PATH = os.path.join(cand_dir, f)
                elif "decoder" in f and f.endswith(".onnx"):
                    DECODER_PATH = os.path.join(cand_dir, f)
                elif "joiner" in f and (f.endswith(".int8.onnx") or f.endswith(".onnx")):
                    JOINER_PATH = os.path.join(cand_dir, f)
            break

class GlobalASREngine:
    """Moteur Sherpa-ONNX instancié une seule fois au démarrage."""
    def __init__(self):
        logger.info("Chargement du modèle Sherpa-ONNX OnlineRecognizer en mémoire...")
        if not os.path.exists(TOKENS_PATH) or not os.path.exists(ENCODER_PATH):
            logger.warning(f"Modèle introuvable dans {STREAMING_DIR}. Téléchargez les modèles avec download_models.sh")
            self.recognizer = None
            return

        self.recognizer = sherpa_onnx.OnlineRecognizer.from_transducer(
            tokens=TOKENS_PATH,
            encoder=ENCODER_PATH,
            decoder=DECODER_PATH,
            joiner=JOINER_PATH,
            num_threads=2,
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
            enable_endpoint_detection=True,
            rule1_min_trailing_silence=1.2,
            rule2_min_trailing_silence=0.8,
            rule3_min_utterance_length=10.0,
        )
        logger.info("Moteur Sherpa-ONNX OnlineRecognizer initialisé et prêt pour inférence CPU ultra-rapide.")

    def create_stream(self):
        if not self.recognizer:
            return None
        return self.recognizer.create_stream()

asr_engine = GlobalASREngine()

class LiveStreamSession:
    """Gère un pipeline FFmpeg en tâche de fond pour une URL HLS et diffuse aux WebSockets."""
    def __init__(self, stream_url: str):
        self.stream_url = stream_url
        self.clients: Set[WebSocket] = set()
        self.is_running = False
        self.task: asyncio.Task = None
        self.process: subprocess.Popen = None

    async def broadcast(self, message: dict):
        if not self.clients:
            return
        payload = json.dumps(message, ensure_ascii=False)
        disconnected = []
        for client in list(self.clients):
            try:
                await client.send_text(payload)
            except Exception:
                disconnected.append(client)
        for client in disconnected:
            self.clients.discard(client)

    async def run(self):
        self.is_running = True
        logger.info(f"Lancement du pipeline audio FFmpeg pour {self.stream_url}")

        # Commande FFmpeg conforme : extraction audio PCM 16kHz mono sans vidéo
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel", "error",
            "-reconnect", "1",
            "-reconnect_at_eof", "1",
            "-reconnect_streamed", "1",
            "-reconnect_delay_max", "2",
            "-i", self.stream_url,
            "-vn",
            "-f", "s16le",
            "-ac", "1",
            "-ar", "16000",
            "pipe:1"
        ]

        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                bufsize=1024 * 32
            )
        except Exception as e:
            logger.error(f"Erreur au lancement de FFmpeg: {e}")
            self.is_running = False
            return

        stream = asr_engine.create_stream()
        if not stream:
            logger.error("Impossible de créer le flux Sherpa-ONNX (modèle non chargé).")
            self.is_running = False
            return

        loop = asyncio.get_event_loop()
        sample_rate = 16000
        # 1600 échantillons = 0.1s de son (3200 octets en 16-bit PCM mono)
        chunk_samples = 1600
        chunk_bytes = chunk_samples * 2

        start_time = time.time()
        last_text = ""

        try:
            while self.is_running and self.clients:
                # Lecture asynchrone non-bloquante du stdout de FFmpeg
                raw_bytes = await loop.run_in_executor(None, self.process.stdout.read, chunk_bytes)
                if not raw_bytes or len(raw_bytes) < 2:
                    await asyncio.sleep(0.01)
                    continue

                # Conversion PCM 16-bit vers float32 normalisé [-1.0, 1.0]
                samples = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0

                # Envoi des données PCM au recognizer
                stream.accept_waveform(sample_rate, samples)

                while asr_engine.recognizer.is_ready(stream):
                    asr_engine.recognizer.decode_stream(stream)

                is_endpoint = asr_engine.recognizer.is_endpoint(stream)
                result = asr_engine.recognizer.get_result(stream)
                current_text = result.text.strip() if hasattr(result, "text") else ""

                current_pts = round(time.time() - start_time, 2)

                if is_endpoint:
                    if current_text:
                        logger.info(f"[PTS: {current_pts}s] FINAL: {current_text}")
                        await self.broadcast({
                            "text": current_text,
                            "pts": current_pts,
                            "is_final": True
                        })
                    asr_engine.recognizer.reset(stream)
                    last_text = ""
                elif current_text and current_text != last_text:
                    last_text = current_text
                    await self.broadcast({
                        "text": current_text,
                        "pts": current_pts,
                        "is_final": False
                    })

                # Évite toute surcharge CPU
                await asyncio.sleep(0.005)

        except Exception as e:
            logger.error(f"Erreur durant la transcription live: {e}")
        finally:
            logger.info("Arrêt de la session FFmpeg et libération des ressources.")
            if self.process:
                try:
                    self.process.terminate()
                    self.process.wait(timeout=2)
                except Exception:
                    self.process.kill()
            self.is_running = False

# Gestionnaire multi-flux par URL
active_sessions: Dict[str, LiveStreamSession] = {}

APK_CANDIDATE_PATHS = [
    os.path.join(BASE_DIR, "pro_iptv.apk"),
    os.path.join(os.path.dirname(BASE_DIR), "pro_iptv.apk"),
    os.path.join(os.path.dirname(BASE_DIR), "Pro_IPTV.apk"),
    os.path.join(os.path.dirname(BASE_DIR), "app", "build", "outputs", "apk", "debug", "app-debug.apk")
]

def get_apk_path() -> str:
    for path in APK_CANDIDATE_PATHS:
        if os.path.exists(path) and os.path.getsize(path) > 1000:
            return path
    return ""

@app.get("/", response_class=HTMLResponse)
def index_download_page():
    apk_path = get_apk_path()
    file_size_mb = f"{os.path.getsize(apk_path) / (1024 * 1024):.1f} MB" if apk_path else "114 MB"
    status_badge = '<span style="background:#E6F4EA;color:#137333;padding:4px 12px;border-radius:16px;font-weight:600;font-size:14px;">✓ Prêt au téléchargement</span>' if apk_path else '<span style="background:#FCE8E6;color:#C5221F;padding:4px 12px;border-radius:16px;font-weight:600;font-size:14px;">En cours de préparation</span>'
    
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Téléchargement Pro IPTV APK</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif; }}
        body {{
            background: #FAFAFC;
            color: #1A1A24;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 24px;
        }}
        .card {{
            background: #FFFFFF;
            border: 1px solid #EAEAEA;
            border-radius: 28px;
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.06), 0 0 1px 1px rgba(0,0,0,0.02);
            width: 100%;
            max-width: 520px;
            padding: 40px;
            text-align: center;
        }}
        .icon-box {{
            width: 88px;
            height: 88px;
            background: linear-gradient(135deg, #00D2FF 0%, #0066FF 100%);
            border-radius: 22px;
            margin: 0 auto 24px auto;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 12px 24px -6px rgba(0,102,255,0.3);
        }}
        .icon-box svg {{
            width: 44px;
            height: 44px;
            fill: #FFFFFF;
        }}
        h1 {{
            font-size: 26px;
            font-weight: 800;
            color: #111827;
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }}
        p.subtitle {{
            color: #6B7280;
            font-size: 15px;
            margin-bottom: 24px;
            line-height: 1.5;
        }}
        .meta-container {{
            background: #F8FAFC;
            border: 1px solid #EEF2F6;
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 28px;
            display: flex;
            justify-content: space-around;
            text-align: center;
        }}
        .meta-item .label {{
            font-size: 12px;
            color: #9CA3AF;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 4px;
        }}
        .meta-item .val {{
            font-size: 15px;
            color: #1F2937;
            font-weight: 700;
        }}
        .btn-download {{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            padding: 18px 24px;
            background: linear-gradient(135deg, #0066FF 0%, #0052CC 100%);
            color: #FFFFFF;
            border: none;
            border-radius: 16px;
            font-size: 16px;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            box-shadow: 0 10px 20px -5px rgba(0,102,255,0.4);
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }}
        .btn-download:hover {{
            transform: translateY(-2px);
            box-shadow: 0 14px 28px -6px rgba(0,102,255,0.5);
        }}
        .features {{
            margin-top: 28px;
            text-align: left;
            border-top: 1px solid #F3F4F6;
            padding-top: 24px;
        }}
        .features h3 {{
            font-size: 14px;
            font-weight: 700;
            color: #374151;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .feature-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            color: #4B5563;
            font-size: 14px;
            margin-bottom: 8px;
        }}
        .feature-item svg {{
            width: 18px;
            height: 18px;
            fill: #10B981;
            flex-shrink: 0;
        }}
    </style>
</head>
<body>
    <div class="card">
        <div class="icon-box">
            <svg viewBox="0 0 24 24"><path d="M21 3H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h5v2h8v-2h5c1.1 0 1.99-.9 1.99-2L23 5c0-1.1-.9-2-2-2zm0 14H3V5h18v12zm-11-2l6-4-6-4v8z"/></svg>
        </div>
        <h1>Pro IPTV Android</h1>
        <p class="subtitle">Lecteur IPTV Haute Définition avec Sous-Titrage IA et Multi-Écrans</p>
        
        <div class="meta-container">
            <div class="meta-item">
                <div class="label">Fichier</div>
                <div class="val">pro_iptv.apk</div>
            </div>
            <div class="meta-item">
                <div class="label">Taille</div>
                <div class="val">{file_size_mb}</div>
            </div>
            <div class="meta-item">
                <div class="label">Version</div>
                <div class="val">v1.0 Release</div>
            </div>
        </div>

        <a href="/pro_iptv.apk" class="btn-download" download="pro_iptv.apk">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/></svg>
            Télécharger pro_iptv.apk
        </a>

        <div class="features">
            <h3>Fonctionnalités intégrées :</h3>
            <div class="feature-item">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
                <span>Live TV, Films VOD & Séries complètes</span>
            </div>
            <div class="feature-item">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
                <span>Sous-titrage vocal en temps réel par IA</span>
            </div>
            <div class="feature-item">
                <svg viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
                <span>Multi-Screen (2 à 4 flux simultanés) & EPG</span>
            </div>
        </div>
    </div>
</body>
</html>"""

@app.get("/pro_iptv.apk")
@app.get("/download")
@app.get("/app-debug.apk")
def download_apk():
    apk_path = get_apk_path()
    if not apk_path or not os.path.exists(apk_path):
        raise HTTPException(status_code=404, detail="Le fichier pro_iptv.apk n'a pas été trouvé.")
    
    return FileResponse(
        path=apk_path,
        media_type="application/vnd.android.package-archive",
        filename="pro_iptv.apk"
    )

@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "model_loaded": asr_engine.recognizer is not None,
        "active_streams_count": len(active_sessions)
    }

@app.websocket("/ws/live")
async def websocket_live_subtitles(
    websocket: WebSocket,
    url: str = Query(..., description="URL du flux HLS .m3u8 à sous-titrer")
):
    """
    Endpoint WebSocket principal pour les flux LIVE :
    ws://SERVEUR:8000/ws/live?url=http://example.com/live.m3u8
    """
    await websocket.accept()
    logger.info(f"Nouveau client connecté pour le flux : {url}")

    if not asr_engine.recognizer:
        await websocket.send_json({"error": "Modèle Sherpa-ONNX non disponible sur le serveur."})
        await websocket.close()
        return

    session = active_sessions.get(url)
    if not session:
        session = LiveStreamSession(stream_url=url)
        active_sessions[url] = session

    session.clients.add(websocket)

    if not session.is_running:
        session.task = asyncio.create_task(session.run())

    try:
        while True:
            # Écoute les pings / messages du client sans bloquer
            await websocket.receive_text()
    except WebSocketDisconnect:
        logger.info(f"Client déconnecté du flux {url}")
    finally:
        session.clients.discard(websocket)
        if not session.clients:
            logger.info(f"Plus aucun auditeur pour {url}, fermeture du pipeline FFmpeg.")
            session.is_running = False
            if session.task:
                session.task.cancel()
            active_sessions.pop(url, None)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, workers=1)
