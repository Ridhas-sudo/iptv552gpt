# Pro IPTV — version V6 pour compilation GitHub

Cette version est préparée pour un dépôt GitHub qui contient directement le projet Android.

## Corrections de build

- Suppression des anciens dépôts Gradle locaux/inutiles.
- Suppression de la tâche `copyApkToRoot` qui créait une dépendance circulaire avec `assembleDebug`.
- Suppression de la logique `.env`/BuildConfig qui n'est pas utilisée par le code Kotlin.
- Un seul fichier `settings.gradle.kts`, un seul `build.gradle.kts` racine et un seul `app/build.gradle.kts`.
- Le workflow GitHub ne décompresse aucun ZIP dans le dépôt.
- Détection des doublons de classes/objets/interfaces Kotlin avant Gradle.
- Vérification des imports Compose mal formés.
- JDK 17 + Gradle 8.9.
- Téléchargement contrôlé de l'AAR Sherpa-ONNX 1.10.42 avant la compilation, avec vérification SHA-256.
- Compilation directe avec `gradle :app:assembleDebug`.
- L'APK est publié comme artifact `Pro_IPTV-debug`.

## Structure attendue du dépôt GitHub

Le contenu du ZIP doit être placé à la racine du dépôt :

```text
settings.gradle.kts
build.gradle.kts
gradle.properties
app/
  build.gradle.kts
  src/main/...
.github/workflows/build-apk.yml
```

Ne gardez pas une ancienne copie de `app/src/main` et ne placez pas un ancien ZIP contenant une deuxième copie du projet dans `app/`.

## Compilation

GitHub → Actions → Build APK → Run workflow.

L'APK se trouve ensuite dans l'artifact `Pro_IPTV-debug`.
