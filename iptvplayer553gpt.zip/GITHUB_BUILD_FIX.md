# GitHub Actions — build propre

Le dépôt doit contenir **un seul projet Android source**. Ne conservez pas d'anciens dossiers `app/src/main/java` ou d'anciens ZIP extraits dans le dépôt.

Les erreurs vues précédemment (`Redeclaration: IptvViewModel`, `viewModel()`, `tvFocusable`, `isFullScreen`) étaient notamment compatibles avec la présence de deux versions du code dans le même dépôt : une ancienne et une nouvelle. Cette version ajoute un contrôle CI qui arrête le build immédiatement si deux déclarations top-level portant le même nom sont présentes.

Le projet ne contient pas `gradlew`. Le workflow utilise donc explicitement Gradle 8.9 via `gradle/actions/setup-gradle`.
